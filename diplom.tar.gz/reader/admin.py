# -*- coding: utf-8 -*-
from reader.models import *
from django.contrib import admin

admin.site.register(News)
